(function () {
  if (typeof window.CustomEvent === "function") {
    return false;
  }

  function CustomEvent(event, params) {
    params = params || {
      bubbles: false,
      cancelable: false,
      detail: undefined
    };
    var evt = document.createEvent("CustomEvent");
    evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
    return evt;
  }

  CustomEvent.prototype = window.Event.prototype;
  window.CustomEvent = CustomEvent;
})();


var currency_left_pos = true;
var race_set = 1;
var country_bitcoin_video_container_top = {};
var tree_boxes_holder_h4_font_size = {};
var frequently_head_button_font_size = {};

var ipdata = [];
var country_name = {
  "BD": "Bangladesh",
  "BE": "Belgium",
  "BF": "Burkina Faso",
  "BG": "Bulgaria",
  "BA": "Bosnia and Herzegovina",
  "BB": "Barbados",
  "WF": "Wallis and Futuna",
  "BL": "Saint Barthelemy",
  "BM": "Bermuda",
  "BN": "Brunei",
  "BO": "Bolivia",
  "BH": "Bahrain",
  "BI": "Burundi",
  "BJ": "Benin",
  "BT": "Bhutan",
  "JM": "Jamaica",
  "BV": "Bouvet Island",
  "BW": "Botswana",
  "WS": "Samoa",
  "BQ": "Bonaire, Saint Eustatius and Saba ",
  "BR": "Brazil",
  "BS": "Bahamas",
  "JE": "Jersey",
  "BY": "Belarus",
  "BZ": "Belize",
  "RU": "Russia",
  "RW": "Rwanda",
  "RS": "Serbia",
  "TL": "East Timor",
  "RE": "Reunion",
  "TM": "Turkmenistan",
  "TJ": "Tajikistan",
  "RO": "Romania",
  "TK": "Tokelau",
  "GW": "Guinea-Bissau",
  "GU": "Guam",
  "GT": "Guatemala",
  "GS": "South Georgia and the South Sandwich Islands",
  "GR": "Greece",
  "GQ": "Equatorial Guinea",
  "GP": "Guadeloupe",
  "JP": "Japan",
  "GY": "Guyana",
  "GG": "Guernsey",
  "GF": "French Guiana",
  "GE": "Georgia",
  "GD": "Grenada",
  "GB": "United Kingdom",
  "GA": "Gabon",
  "SV": "El Salvador",
  "GN": "Guinea",
  "GM": "Gambia",
  "GL": "Greenland",
  "GI": "Gibraltar",
  "GH": "Ghana",
  "OM": "Oman",
  "TN": "Tunisia",
  "JO": "Jordan",
  "HR": "Croatia",
  "HT": "Haiti",
  "HU": "Hungary",
  "HK": "Hong Kong",
  "HN": "Honduras",
  "HM": "Heard Island and McDonald Islands",
  "VE": "Venezuela",
  "PR": "Puerto Rico",
  "PS": "Palestinian Territory",
  "PW": "Palau",
  "PT": "Portugal",
  "SJ": "Svalbard and Jan Mayen",
  "PY": "Paraguay",
  "IQ": "Iraq",
  "PA": "Panama",
  "PF": "French Polynesia",
  "PG": "Papua New Guinea",
  "PE": "Peru",
  "PK": "Pakistan",
  "PH": "Philippines",
  "PN": "Pitcairn",
  "PL": "Poland",
  "PM": "Saint Pierre and Miquelon",
  "ZM": "Zambia",
  "EH": "Western Sahara",
  "EE": "Estonia",
  "EG": "Egypt",
  "ZA": "South Africa",
  "EC": "Ecuador",
  "IT": "Italy",
  "VN": "Vietnam",
  "SB": "Solomon Islands",
  "ET": "Ethiopia",
  "SO": "Somalia",
  "ZW": "Zimbabwe",
  "SA": "Saudi Arabia",
  "ES": "Spain",
  "ER": "Eritrea",
  "ME": "Montenegro",
  "MD": "Moldova",
  "MG": "Madagascar",
  "MF": "Saint Martin",
  "MA": "Morocco",
  "MC": "Monaco",
  "UZ": "Uzbekistan",
  "MM": "Myanmar",
  "ML": "Mali",
  "MO": "Macao",
  "MN": "Mongolia",
  "MH": "Marshall Islands",
  "MK": "Macedonia",
  "MU": "Mauritius",
  "MT": "Malta",
  "MW": "Malawi",
  "MV": "Maldives",
  "MQ": "Martinique",
  "MP": "Northern Mariana Islands",
  "MS": "Montserrat",
  "MR": "Mauritania",
  "IM": "Isle of Man",
  "UG": "Uganda",
  "TZ": "Tanzania",
  "MY": "Malaysia",
  "MX": "Mexico",
  "IL": "Israel",
  "FR": "France",
  "IO": "British Indian Ocean Territory",
  "SH": "Saint Helena",
  "FI": "Finland",
  "FJ": "Fiji",
  "FK": "Falkland Islands",
  "FM": "Micronesia",
  "FO": "Faroe Islands",
  "NI": "Nicaragua",
  "NL": "Netherlands",
  "NO": "Norway",
  "NA": "Namibia",
  "VU": "Vanuatu",
  "NC": "New Caledonia",
  "NE": "Niger",
  "NF": "Norfolk Island",
  "NG": "Nigeria",
  "NZ": "New Zealand",
  "NP": "Nepal",
  "NR": "Nauru",
  "NU": "Niue",
  "CK": "Cook Islands",
  "XK": "Kosovo",
  "CI": "Ivory Coast",
  "CH": "Switzerland",
  "CO": "Colombia",
  "CN": "China",
  "CM": "Cameroon",
  "CL": "Chile",
  "CC": "Cocos Islands",
  "CA": "Canada",
  "CG": "Republic of the Congo",
  "CF": "Central African Republic",
  "CD": "Democratic Republic of the Congo",
  "CZ": "Czech Republic",
  "CY": "Cyprus",
  "CX": "Christmas Island",
  "CR": "Costa Rica",
  "CW": "Curacao",
  "CV": "Cape Verde",
  "CU": "Cuba",
  "SZ": "Swaziland",
  "SY": "Syria",
  "SX": "Sint Maarten",
  "KG": "Kyrgyzstan",
  "KE": "Kenya",
  "SS": "South Sudan",
  "SR": "Suriname",
  "KI": "Kiribati",
  "KH": "Cambodia",
  "KN": "Saint Kitts and Nevis",
  "KM": "Comoros",
  "ST": "Sao Tome and Principe",
  "SK": "Slovakia",
  "KR": "South Korea",
  "SI": "Slovenia",
  "KP": "North Korea",
  "KW": "Kuwait",
  "SN": "Senegal",
  "SM": "San Marino",
  "SL": "Sierra Leone",
  "SC": "Seychelles",
  "KZ": "Kazakhstan",
  "KY": "Cayman Islands",
  "SG": "Singapore",
  "SE": "Sweden",
  "SD": "Sudan",
  "DO": "Dominican Republic",
  "DM": "Dominica",
  "DJ": "Djibouti",
  "DK": "Denmark",
  "VG": "British Virgin Islands",
  "DE": "Germany",
  "YE": "Yemen",
  "DZ": "Algeria",
  "US": "United States",
  "UY": "Uruguay",
  "YT": "Mayotte",
  "UM": "United States Minor Outlying Islands",
  "LB": "Lebanon",
  "LC": "Saint Lucia",
  "LA": "Laos",
  "TV": "Tuvalu",
  "TW": "Taiwan",
  "TT": "Trinidad and Tobago",
  "TR": "Turkey",
  "LK": "Sri Lanka",
  "LI": "Liechtenstein",
  "LV": "Latvia",
  "TO": "Tonga",
  "LT": "Lithuania",
  "LU": "Luxembourg",
  "LR": "Liberia",
  "LS": "Lesotho",
  "TH": "Thailand",
  "TF": "French Southern Territories",
  "TG": "Togo",
  "TD": "Chad",
  "TC": "Turks and Caicos Islands",
  "LY": "Libya",
  "VA": "Vatican",
  "VC": "Saint Vincent and the Grenadines",
  "AE": "United Arab Emirates",
  "AD": "Andorra",
  "AG": "Antigua and Barbuda",
  "AF": "Afghanistan",
  "AI": "Anguilla",
  "VI": "U.S. Virgin Islands",
  "IS": "Iceland",
  "IR": "Iran",
  "AM": "Armenia",
  "AL": "Albania",
  "AO": "Angola",
  "AQ": "Antarctica",
  "AS": "American Samoa",
  "AR": "Argentina",
  "AU": "Australia",
  "AT": "Austria",
  "AW": "Aruba",
  "IN": "India",
  "AX": "Aland Islands",
  "AZ": "Azerbaijan",
  "IE": "Ireland",
  "ID": "Indonesia",
  "UA": "Ukraine",
  "QA": "Qatar",
  "MZ": "Mozambique"
};
var country_name_ru = {
  "BD": "Р‘Р°РЅРіР»Р°РґРµС€Р°",
  "BE": "Р‘РµР»СЊРіРёРё",
  "BF": "Р‘СѓСЂРєРёРЅР°-Р¤Р°СЃРѕ",
  "BG": "Р‘РѕР»РіР°СЂРёРё",
  "BA": "Р‘РѕСЃРЅРёРё Рё Р“РµСЂС†РµРіРѕРІРёРЅС‹",
  "BB": "Р‘Р°СЂР±Р°РґРѕСЃС‹",
  "WF": "РЈРѕР»Р»РёСЃ Рё Р¤СѓС‚СѓРЅР°",
  "BL": "РЎРµРЅ-Р‘Р°СЂС‚РµР»РµРјРё",
  "BM": "Р‘РµСЂРјСѓРґСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "BN": "Р‘СЂСѓРЅРµР№",
  "BO": "Р‘РѕР»РёРІРёРё",
  "BH": "Р‘Р°С…СЂРµР№РЅР°",
  "BI": "Р‘СѓСЂСѓРЅРґРё",
  "BJ": "Р‘РµРЅРёРЅР°",
  "BT": "Р‘СѓС‚Р°РЅС‹",
  "JM": "РЇРјР°Р№РєРё",
  "BV": "РћСЃС‚СЂРѕРІ Р‘СѓРІРµ",
  "BW": "Р‘РѕС‚СЃРІР°РЅР°",
  "WS": "РЎР°РјРѕР°",
  "BQ": "Р‘РѕРЅР°Р№СЂРµ, РЎРµРЅС‚-Р­СЃС‚Р°С‚РёСѓСЃ Рё РЎР°Р±Р° ",
  "BR": "Р‘СЂР°Р·РёР»РёСЏ",
  "BS": "Р‘Р°РіР°РјСЃРєРёРµ Рѕ-РІР°",
  "JE": "Р”Р¶РµСЂСЃРё",
  "BY": "Р‘РµР»Р°СЂСѓСЃРёРё",
  "BZ": "Р‘РµР»РёР·РёРё",
  "RU": "Р РѕСЃСЃРёРё",
  "RW": "Р СѓР°РЅРґС‹",
  "RS": "РЎРµСЂР±РёРё",
  "TL": "Р’РѕСЃС‚РѕС‡РЅРѕРіРѕ РўРёРјРѕСЂР°",
  "RE": "Р РµСЋРЅСЊРѕРЅР°",
  "TM": "РўСѓСЂРєРјРµРЅРёСЃС‚Р°РЅР°",
  "TJ": "РўР°РґР¶РёРєРёСЃС‚Р°РЅР°",
  "RO": "Р СѓРјС‹РЅРёРё",
  "TK": "РўРѕРєРµР»Р°Сѓ",
  "GW": "Р“РІРёРЅРµСЏ-Р‘РёСЃР°Сѓ",
  "GU": "Р“СѓР°РјС‹",
  "GT": "Р“РІР°С‚РµРјР°Р»С‹",
  "GS": "Р®Р¶РЅРѕР№ Р“РµРѕСЂРіРёРё Рё Р®Р¶РЅРѕР№ РЎР°РЅРґРІРёС‡РµРІС‹С… РѕСЃС‚СЂРѕРІРѕРІ",
  "GR": "Р“СЂРµС†РёРё",
  "GQ": "Р­РєРІР°С‚РѕСЂРёР°Р»СЊРЅРѕР№ Р“РІРёРЅРµРё",
  "GP": "Р“РІР°РґРµР»СѓРїС‹",
  "JP": "РЇРїРѕРЅРёРё",
  "GY": "Р“Р°Р№Р°РЅС‹",
  "GG": "Р“РµСЂРЅСЃРё",
  "GF": "Р¤СЂР°РЅС†СѓР·СЃРєРѕР№ Р“РІРёР°РЅС‹",
  "GE": "Р“СЂСѓР·РёРё",
  "GD": "Р“СЂРµРЅР°РґС‹",
  "GB": "РћР±СЉРµРґРёРЅРµРЅРЅРѕРіРѕ РљРѕСЂРѕР»РµРІСЃС‚РІР°",
  "GA": "Р“Р°Р±РѕРЅ",
  "SV": "Р­Р»СЊ РЎР°Р»СЊРІР°РґРѕСЂС‹",
  "GN": "Р“РІРёРЅРµРё",
  "GM": "Р“Р°РјР±РёРё",
  "GL": "Р“СЂРµРЅР»Р°РЅРґРёРё",
  "GI": "Р“РёР±СЂР°Р»С‚Р°СЂС‹",
  "GH": "Р“Р°РЅС‹",
  "OM": "РћРјР°РЅС‹",
  "TN": "РўСѓРЅРёСЃС‹",
  "JO": "РРѕСЂРґР°РЅРёРё",
  "HR": "РҐРѕСЂРІР°С‚РёРё",
  "HT": "Р“Р°РёС‚Рё",
  "HU": "Р’РµРЅРіСЂРёРё",
  "HK": "Р“РѕРЅРєРѕРЅРіР°",
  "HN": "Р“РѕРЅРґСѓСЂР°СЃР°",
  "HM": "РћСЃС‚СЂРѕРІР° РҐРµСЂРґ Рё РњР°РєРґРѕРЅР°Р»СЊРґР°",
  "VE": "Р’РµРЅРµСЃСѓСЌР»С‹",
  "PR": "РџСѓСЌСЂС‚Рѕ-Р РёРєРѕ",
  "PS": "РџР°Р»РµСЃС‚РёРЅСЃРєРѕР№ С‚РµСЂСЂРёС‚РѕСЂРёРё",
  "PW": "РџР°Р»Р°Сѓ",
  "PT": "РџРѕСЂС‚СѓРіР°Р»РёРё",
  "SJ": "РЎРІР°Р»СЊР±Р°СЂРґР° Рё РЇРЅ-РњР°Р№РµРЅ",
  "PY": "РџР°СЂР°РіРІР°Рё",
  "IQ": "РСЂР°РєР°",
  "PA": "РџР°РЅР°РјС‹",
  "PF": "Р¤СЂР°РЅС†СѓР·СЃРєРѕР№ РџРѕР»РёРЅРµР·РёРё",
  "PG": "РџР°РїСѓР° - РќРѕРІР°Р№ Р“РІРёРЅРµРё",
  "PE": "РџРµСЂСѓ",
  "PK": "РџР°РєРёСЃС‚Р°РЅР°",
  "PH": "Р¤РёР»РёРїРёРЅРѕРІ",
  "PN": "РџРёС‚РєСЌСЂРЅР°",
  "PL": "РџРѕР»СЊС€Рё",
  "PM": "РЎРµРЅ-РџСЊРµСЂР° Рё РњРёРєРµР»РѕРЅР°",
  "ZM": "Р—Р°РјР±РёРё",
  "EH": "Р—Р°РїР°РґРЅРѕР№ РЎР°С…Р°СЂС‹",
  "EE": "Р­СЃС‚РѕРЅРёРё",
  "EG": "Р•РіРёРїС‚Р°",
  "ZA": "Р®Р¶РЅРѕР№ РђС„СЂРёРєРё",
  "EC": "Р­РєРІР°РґРѕСЂР°",
  "IT": "РС‚Р°Р»РёРё",
  "VN": "Р’СЊРµС‚РЅР°РјР°",
  "SB": "РЎРѕР»РѕРјРѕРЅРѕРІС‹С… РѕСЃС‚СЂРѕРІРѕРІ",
  "ET": "Р­С„РёРѕРїРёРё",
  "SO": "РЎРѕРјР°Р»Рё",
  "ZW": "Р—РёРјР±Р°Р±РІРµ",
  "SA": "РЎР°СѓРґРѕРІСЃРєРѕР№ РђСЂР°РІРёРё",
  "ES": "РСЃРїР°РЅРёРё",
  "ER": "Р­СЂРёС‚СЂРµРё",
  "ME": "Р§РµСЂРЅРѕРіРѕСЂРёРё",
  "MD": "РњРѕР»РґРѕРІС‹",
  "MG": "РњР°РґР°РіР°СЃРєР°СЂР°",
  "MF": "РЎРµРЅ-РњР°СЂС‚РµРЅР°",
  "MA": "РњР°СЂРѕРєРєРѕ",
  "MC": "РњРѕРЅР°РєРѕ",
  "UZ": "РЈР·Р±РµРєРёСЃС‚Р°РЅР°",
  "MM": "РњСЊСЏРЅРјР°",
  "ML": "РњР°Р»Рё",
  "MO": "Macao",
  "MN": "РњРѕРЅРіРѕР»РёРё",
  "MH": "РњР°СЂС€Р°Р»Р»РѕРІС‹С… РѕСЃС‚СЂРѕРІРѕРІ",
  "MK": "РњР°РєРµРґРѕРЅРёРё",
  "MU": "РњР°РІСЂРёРєРёРё",
  "MT": "РњР°Р»СЊС‚С‹",
  "MW": "РњР°Р»Р°РІРё",
  "MV": "РњР°Р»СЊРґРёРІРѕРІ",
  "MQ": "РњР°СЂС‚РёРЅРёРєР°",
  "MP": "РЎРµРІРµСЂРЅРѕ РњР°СЂРёР°РЅСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "MS": "РњРѕРЅСЃРµСЂСЂР°С‚",
  "MR": "РњР°РІСЂРёС‚Р°РЅРёСЏ",
  "IM": "РћСЃС‚СЂРѕРІ РњСЌРЅ",
  "UG": "РЈРіР°РЅРґР°",
  "TZ": "РўР°РЅР·Р°РЅРёРё",
  "MY": "РњР°Р»Р°Р№Р·РёРё",
  "MX": "РњРµРєСЃРёРєРё",
  "IL": "РР·СЂР°РёР»СЏ",
  "FR": "Р¤СЂР°РЅС†РёРё",
  "IO": "Р‘СЂРёС‚Р°РЅСЃРєРёС… С‚РµСЂСЂРёС‚РѕСЂРёРё РРЅРґРёР№СЃРєРѕРіРѕ РѕРєРµР°РЅР°",
  "SH": "РћСЃС‚СЂРѕРІ РЎРІСЏС‚РѕР№ Р•Р»РµРЅС‹",
  "FI": "Р¤РёРЅР»СЏРЅРґРёРё",
  "FJ": "Р¤РёРґР¶Рё",
  "FK": "Р¤РѕР»РєР»РµРЅРґСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "FM": "РњРёРєСЂРѕРЅРµР·РёРё",
  "FO": "Р¤Р°СЂРµСЂСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "NI": "РќРёРєР°СЂР°РіСѓР°",
  "NL": "РќРёРґРµСЂР»Р°РЅРґРѕРІ",
  "NO": "РќРѕСЂРІРµРіРёРё",
  "NA": "РќР°РјРёР±РёРё",
  "VU": "Р’Р°РЅСѓР°С‚С‹",
  "NC": "РќРѕРІРѕР№ РљР°Р»РµРґРѕРЅРёРё",
  "NE": "РќРёРіРµСЂС‹",
  "NF": "РћСЃС‚СЂРѕРІР° РќРѕСЂС„РѕР»Рє",
  "NG": "РќРёРіРµСЂРёРё",
  "NZ": "РќРѕРІРѕР№ Р—РµР»Р°РЅРґРёРё",
  "NP": "РќРµРїР°Р»Р°",
  "NR": "РќР°СѓСЂС‹",
  "NU": "РќРёСѓСЌРё",
  "CK": "РћСЃС‚СЂРѕРІРѕРІ РљСѓРєР°",
  "XK": "РљРѕСЃРѕРІРѕ",
  "CI": "РљРѕС‚-Рґ'РРІСѓР°СЂ",
  "CH": "РЁРІРµР№С†Р°СЂРёРё",
  "CO": "РљРѕР»СѓРјР±РёРё",
  "CN": "РљРёС‚Р°СЏ",
  "CM": "РљР°РјРµСЂСѓРЅР°",
  "CL": "Р§РёР»Рё",
  "CC": "РљРѕРєРѕСЃРѕРІС‹С… РѕСЃС‚СЂРѕРІРѕРІ",
  "CA": "РљР°РЅР°РґС‹",
  "CG": "Р РµСЃРїСѓР±Р»РёРєРё РљРѕРЅРіРѕ",
  "CF": "Р¦РµРЅС‚СЂР°Р»СЊРЅРѕ-РђС„СЂРёРєР°РЅСЃРєРѕР№ Р РµСЃРїСѓР±Р»РёРєРё",
  "CD": "Р”РµРјРѕРєСЂР°С‚РёС‡РµСЃРєРѕР№ Р РµСЃРїСѓР±Р»РёРєРё РљРѕРЅРіРѕ",
  "CZ": "Р§РµС…РёРё",
  "CY": "РљРёРїСЂР°",
  "CX": "РћСЃС‚СЂРѕРІР° Р РѕР¶РґРµСЃС‚РІРѕ",
  "CR": "РљРѕСЃС‚Р°-Р РёРєРё",
  "CW": "РљСЋСЂР°СЃР°Рѕ",
  "CV": "РљР°Р±Рѕ-Р’РµСЂРґРµ",
  "CU": "РљСѓР±С‹",
  "SZ": "РЎРІР°Р·РёР»РµРЅРґ",
  "SY": "РЎРёСЂРёРё",
  "SX": "РЎРёРЅС‚-РњР°Р°СЂС‚РµРЅР°",
  "KG": "РљРёСЂРіРёР·РёРё",
  "KE": "РљРµРЅРёРё",
  "SS": "СЋР¶РЅРѕРіРѕ РЎСѓРґР°РЅР°",
  "SR": "РЎСѓСЂРёРЅР°РјРё",
  "KI": "РљРёСЂРёР±Р°С‚Рё",
  "KH": "РљР°РјР±РѕРґР¶Рё",
  "KN": "РЎРµРЅС‚-РљРёС‚СЃР° Рё РќРµРІРёСЃР°",
  "KM": "РљРѕРјРѕСЂСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "ST": "РЎР°РЅ-РўРѕРјРµ Рё РџСЂРёРЅСЃРёРїРё",
  "SK": "РЎР»РѕРІР°РєРёРё",
  "KR": "Р®Р¶РЅРѕР№ РљРѕСЂРµРё",
  "SI": "РЎР»РѕРІРµРЅРёРё",
  "KP": "РЎРµРІРµСЂРЅРѕР№ РљРѕСЂРµС‚",
  "KW": "РљСѓРІРµР№С‚Р°",
  "SN": "РЎРµРЅРµРіР°Р»Р°",
  "SM": "РЎР°РЅ-РњР°СЂРёРЅР°",
  "SL": "РЎСЊРµСЂСЂР°-Р›РµРѕРЅРµ",
  "SC": "РЎРµР№С€РµР»СЊСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "KZ": "РљР°Р·Р°С…СЃС‚Р°РЅР°",
  "KY": "РљР°Р№РјР°РЅРѕРІС‹С… РћСЃС‚СЂРѕРІРѕРІ",
  "SG": "РЎРёРЅРіР°РїСѓСЂР°",
  "SE": "РЁРІРµС†РёРё",
  "SD": "РЎСѓРґР°РЅРІ",
  "DO": "Р”РѕРјРёРЅРёРєР°РЅСЃРєРѕР№ Р РµСЃРїР±Р»РёРєРё",
  "DM": "Р”РѕРјРёРЅРёРєР°",
  "DJ": "Р”Р¶РёР±СѓС‚Рё",
  "DK": "Р”Р°РЅРёРё",
  "VG": "Р‘СЂРёС‚Р°РЅСЃРєРёС… Р’РёСЂРіРёРЅСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "DE": "Р“РµСЂРјР°РЅРёРё",
  "YE": "Р™РµРјРµРЅР°",
  "DZ": "РђР»Р¶РёСЂР°",
  "US": "РЎРѕРµРґРёРЅРµРЅРЅС‹С… РЁС‚Р°С‚РѕРІ",
  "UY": "РЈСЂСѓРіРІР°Рё",
  "YT": "РњР°Р№РѕС‚С‚С‹",
  "UM": "РњР°Р»С‹С… РѕС‚РґР°Р»РµРЅРЅС‹С… РѕСЃС‚СЂРѕРІРѕРІ РЎРѕРµРґРёРЅРµРЅРЅС‹С… РЁС‚Р°С‚РѕРІ",
  "LB": "Р›РёРІР°РЅС‹",
  "LC": "РЎР°РЅРєС‚-Р›СЋСЃРёРё",
  "LA": "Р›Р°РѕСЃС‹",
  "TV": "РўСѓРІР°Р»СѓРё",
  "TW": "РўР°Р№РІР°РЅРё",
  "TT": "РўСЂРёРЅРёРґР°РґС‹ Рё РўРѕР±Р°РіРѕ",
  "TR": "РўСѓСЂС†РёРё",
  "LK": "РЁСЂРё-Р›Р°РЅРєРё",
  "LI": "Р›РёС…С‚РµРЅС€С‚РµР№РЅР°",
  "LV": "Р›Р°С‚РІРёРё",
  "TO": "РўРѕРЅРіР°",
  "LT": "Р›РёС‚РІС‹",
  "LU": "Р›СЋРєСЃРµРјР±СѓСЂРіР°",
  "LR": "Р›РёР±РµСЂРёРё",
  "LS": "Р›РµСЃРѕС‚С‹",
  "TH": "РўР°РёР»Р°РЅРґР°",
  "TF": "Р®Р¶РЅРѕР№ Р¤СЂР°РЅС†СѓР·СЃРєРѕР№ РўРµСЂСЂРёС‚РѕСЂРёРё",
  "TG": "РРґС‚РёРё",
  "TD": "Р§Р°РґР°",
  "TC": "РћСЃС‚СЂРѕРІРѕРІ РўРµСЂРєСЃР° Рё РљР°Р№РєРѕСЃР°",
  "LY": "Р›РёРІРёРё",
  "VA": "Р’Р°С‚РёРєР°РЅР°",
  "VC": "РЎРІСЏС‚РѕР№ Р’РёРЅСЃРµРЅС‚Р° Рё Р“СЂРµРЅР°РґРёРЅС‹",
  "AE": "РћР±СЉРµРґРёРЅРµРЅРЅС‹С… РђСЂР°Р±СЃРєРёС… Р­РјРёСЂР°С‚РѕРІ",
  "AD": "РђРЅРґРѕСЂСЂС‹",
  "AG": "РђРЅС‚РёРіСѓРё Рё Р‘Р°СЂР±СѓРґР°Рё",
  "AF": "РђС„РіР°РЅРёСЃС‚Р°РЅР°",
  "AI": "РђРЅРіРёР»СЊРё",
  "VI": "Р’РёСЂРіРёРЅСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ РЎРЁРђ",
  "IS": "РСЃР»Р°РЅРґРёРё",
  "IR": "РСЂР°РЅР°",
  "AM": "РђСЂРјРµРЅРёРё",
  "AL": "РђР»Р±Р°РЅРёСЏ",
  "AO": "РђРЅРіРѕР»С‹",
  "AQ": "РђРЅС‚Р°СЂРєС‚РёРґС‹",
  "AS": "РђРјРµСЂРёРєР°РЅСЃРєРёС… РЎР°РјРѕР°",
  "AR": "РђСЂРіРµРЅС‚РёРЅС‹",
  "AU": "РђРІСЃС‚СЂР°Р»РёРё",
  "AT": "РђРІСЃС‚СЂРёРё",
  "AW": "РђСЂСѓР±С‹",
  "IN": "РРЅРґРёРё",
  "AX": "РђР»Р°РЅРґСЃРєРёС… РѕСЃС‚СЂРѕРІРѕРІ",
  "AZ": "РђР·РµСЂР±Р°Р№РґР¶Р°РЅР°",
  "IE": "РСЂР»Р°РЅРґРёРё",
  "ID": "РРЅРґРѕРЅРµР·РёРё",
  "UA": "РЈРєСЂР°РёРЅС‹",
  "QA": "РљР°С‚Р°СЂС‹",
  "MZ": "РњРѕР·Р°РјР±РёРєРё"
};


$.ajax({
  url: "https://ipinfo.io/geo",
  dataType: 'json',
  async: false,
  success: function (data) {
    // console.log( data )
    ipdata = {
      "city": "Moscow",
      "state": "Moscow City",
      "country": "Russia",
      "country_code": "RU",
      "phone_code": {
        "name": "Russia",
        "dial_code": "380",
        "code": "RU",
        "city": "Ternopil",
        "state": "Ternopilska Oblast",
        "symbol": "\\u20b4",
        "vtt": "Russian.vtt"
      },
      "currency": { "name": "USD", "symbol": "$" },
      "currency_left_pos": false,
      "race_set": 1,
      "vtt": "Russian.vtt",
      "country_bitcoin_video_container_top": {
        "287": { "-404px": ["de", "at", "ch", "fr"] },
        "400": {
          "-430px": ["de", "at", "ch", "fr"],
          "-450px": ["ar", "cl", "co", "cr", "es", "mx", "pa", "pe", "pr", "ru", "it", "br"]
        },
        "450": { "-430px": ["de", "at", "ch", "fr"] },
        "540": {
          "-430px": ["de", "at", "ch"],
          "-450px": ["ar", "cl", "co", "cr", "es", "mx", "pa", "pe", "pr", "ru", "fr", "it", "br"]
        }
      },
      "tree_boxes_holder_h4_font_size": { "400": { "18px": ["de", "at", "ch"] } },
      "frequently_head_button_font_size": { "18px": ["de", "at", "ch"] },
      "format": "DD\/MM\/YYYY",
      "city_first": false
    }
    ipdata.city = data.city;
    ipdata.country_code = data.country;
    ipdata.state = data.region;
    ipdata.country = country_name[data.country];
  }
});


if (ipdata.currency_left_pos != undefined) {
  currency_left_pos = ipdata.currency_left_pos;
}
if (ipdata.race_set != undefined) {
  race_set = ipdata.race_set;
}
if (ipdata.country_bitcoin_video_container_top != undefined) {
  country_bitcoin_video_container_top = ipdata.country_bitcoin_video_container_top;
}
if (ipdata.tree_boxes_holder_h4_font_size != undefined) {
  tree_boxes_holder_h4_font_size = ipdata.tree_boxes_holder_h4_font_size;
}
if (ipdata.frequently_head_button_font_size != undefined) {
  frequently_head_button_font_size = ipdata.frequently_head_button_font_size;
}
var force_en = getURLParameter("en");
force_en = (force_en == 1) ? true : false;
var pixdis = getURLParameter("pixdis");
var pixid = getURLParameter("pixid");
var pixval = getURLParameter("pixval");
if (pixid == null) {
  pixid = "0000000000000";
}
if (pixval == null) {
  pixval = 0.5;
}
if (pixdis == null) {
  pixdis = 0;
}

// function _formLoad() {
//     console.log("LOOOAAD");
//     if (typeof pixel_load !== "undefined") {
//         console.log("Pixel Load V");
//         console.log(pixel_load);
//         $("body").append(pixel_load);
//     }
// }

// function _RegistrationDone() {
//     if (typeof pixel_reg !== "undefined") {
//         console.log("Pixel Reg V");
//         console.log(pixel_reg);
//         $("body").append(pixel_reg);
//     }
//     $('[data-init="broker-url"]').attr("onclick", 'location.href = "' + data.redirect_url + '";');
//     $('[data-init="broker-logo"]').each(function() {
//         var obj = $(this);
//         var imgurl = "img/" + data.broker_image;
//         obj.attr("src", imgurl);
//     });
//     $('[data-init="broker-name"]').each(function() {
//         var obj = $(this);
//         obj.html(data.broker_name);
//     });
// }
var names = ["Nikolai", "Nikolas", "Nile", "Nils", "Noah", "Noe", "Noel", "Nolan", "Norbert", "Norman", "Nyle", "Oakes", "Oakley", "Oberon", "Octavio", "Oisin", "Olaf", "Oli", "Oliver", "Ollie", "Olly", "Omar", "Kye", "Kylar", "Kyle", "Kylen", "Kyler", "Kyran", "Kyrin", "Kyron", "Lacey", "Lachlan", "Lake", "Lamar", "Lamont", "Joel", "Joey", "Johan", "John", "Johnathan", "Johnathon", "Johnnie", "Johnny", "Brady", "Braeden", "Bram", "Branden", "Brandon", "Brantley", "Braxton", "Bray", "Brayan", "Brayden", "Braydon", "Braylon", "Breck", "Brendan", "Brenden", "Brendon", "Brennan", "Brennon", "Brent", "Brentley", "Brenton", "Bret", "Brett", "Brevin", "Brevyn", "Brian", "Brice", "Bridie", "Brie", "Brighton", "Brinley", "Brock", "Brod", "Brodie", "Aaliyah", "Aarushi", "Abagail", "Abbey", "Abbi", "Abbie", "Abby", "Abi", "Abia", "Abigail", "Abree", "Abrianna", "Abrielle", "Aby", "Acacia", "Muriel", "Mya", "Myfanwy", "Myla", "Myra", "Myrna", "Myrtle", "Nadene", "Nadia", "Nadine", "Naja", "Nala", "Nana", "Nancy", "Nanette", "Naomi", "Natalia", "Rosemary", "Rosetta", "Rosie", "Rosy", "Rowan", "Rowena", "Roxana", "Roxanne", "Roxie", "Roxy", "Rozlynn", "Ruby", "Rue", "Ruth", "Ruthie", "Ryanne", "Rydel", "Rylee", "Ryleigh", "Rylie", "Sabina", "Sabine", "Sable", "Sabrina", "Sade",],
  tBodyEl, tMobileBody, _dateToday = moment().format(ipdata.format),
  cryptoCurrencyList = ["EOS/ETH", "LTC/EOS", "ETH/LTC", "BTC/ETH", "XLM/BTC"],
  translations, currencyRates, userCurrency, userCurrencySymbol, exchangeIndex, namesLocalised,
  validatorFirst, validatorLast, validatorEmail, validatorPassword, validatorPasswordConf,
  validatorPhone;
countryColors = {
  AT: ["#ed2939", "#ed2939"],
  UA: ["#0005ff", "#FDFF38"],
  FR: ["#666666", "#0005ff"],
  AU: ["#00008b", "#ff0000"],
  CH: ["#ff0000", "#ff0000"],
  DE: ["#000000", "#dd0000"],
  DK: ["#c60c30", "#c60c30"],
  GB: ["#ff0000", "#00008b"],
  IE: ["#169b62", "#ff883e"],
  IT: ["#009246", "#ce2b37"],
  NL: ["#ae1c28", "#21468b"],
  NO: ["#ef2b2d", "#002868"],
  NZ: ["#00247d", "#cc142b"],
  SE: ["#006aa7", "#fecc00"],
  ZA: ["#FFB612", "#007A4D"]
};

function getRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
}

function getURLParameter(name) {
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  var query_string = {};
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (typeof query_string[pair[0]] === "undefined") {
      query_string[pair[0]] = decodeURIComponent(pair[1]);
    } else {
      if (typeof query_string[pair[0]] === "string") {
        var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
        query_string[pair[0]] = arr;
      } else {
        query_string[pair[0]].push(decodeURIComponent(pair[1]));
      }
    }
  }
  return (query_string[name] != undefined) ? query_string[name] : "";
}

function _initFb() {
  !function (f, b, e, v, n, t, s) {
    if (f.fbq) {
      return;
    }
    n = f.fbq = function () {
      n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
    };
    if (!f._fbq) {
      f._fbq = n;
    }
    n.push = n;
    n.loaded = !0;
    n.version = "2.0";
    n.queue = [];
    t = b.createElement(e);
    t.async = !0;
    t.src = v;
    s = b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t, s);
  }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
}

function generateRandom(init) {
  if (namesLocalised !== undefined) {
    var index = Math.floor(Math.random() * namesLocalised.length);
    var rName = namesLocalised[index].name + " " + namesLocalised[index].surname.charAt(0) + ".";
    var name = rName;
  } else {
    var rName = getRandomInt(names.length - 1);
    var name = names[rName];
  }
  var rCrypto = getRandomInt(cryptoCurrencyList.length - 1);
  var rValue = getRandomInt(1000);
  var just_won = "właśnie wygrał";
  // if (typeof translations == "undefined") {
  //   var just_won = "just won";
  // } else {
  //   var just_won = translations["in-table-just-won-trade"];
  // }
  if (init === 1) {
    var currency_new = "<span data-init='visitor-currency-symbol'>$</span><span data-init='profit-value-zero'>" + rValue + "</span>";
    if (!currency_left_pos) {
      currency_new = "<span data-init='visitor-currency-symbol'>$</span><span data-init='profit-value-zero'>" + rValue + "</span>";
    }
    return "<tr><td><b><a data-init='table-user-name'>" + name + "</a></b> <a data-i18n='in-table-just-won-trade'>właśnie wygrał</a>...</td><td><b>" + currency_new + "</b></td><td>" + _dateToday + "</td><td>" + cryptoCurrencyList[rCrypto] + '</td><td><i class="fa fa-check"></i></td></tr>';
  } else {
    var currency_new = "$" + convertCurrency(rValue);
    if (!currency_left_pos) {
      currency_new = "$" + convertCurrency(rValue);
    }
    return "<tr><td><b>" + name + "</b> " + just_won + "...</td><td><b>" + currency_new + "</b></td><td>" + _dateToday + "</td><td>" + cryptoCurrencyList[rCrypto] + '</td><td><i class="fa fa-check"></i></td></tr>';
  }
}

function generateRandomMobile(init) {
  if (namesLocalised !== undefined) {
    var index = Math.floor(Math.random() * namesLocalised.length);
    var rName = namesLocalised[index].name + " " + namesLocalised[index].surname.charAt(0) + ".";
    var name = rName;
  } else {
    var rName = getRandomInt(names.length - 1);
    var name = names[rName];
  }
  var rCrypto = getRandomInt(cryptoCurrencyList.length - 1);
  var rValue = getRandomInt(1000);
  var just_won = "właśnie wygrał";
  // if (typeof translations == "undefined") {
  //   var just_won = "just won";
  // } else {
  //   var just_won = translations["in-table-just-won-trade"];
  // }
  if (init === 1) {
    var currency_new = "<span data-init='visitor-currency-symbol'>$</span><span data-init='profit-value-zero'>" + rValue + "</span>";
    if (!currency_left_pos) {
      currency_new = "<span data-init='visitor-currency-symbol'>$</span><span data-init='profit-value-zero'>" + rValue + "</span>";
    }
    return "<div class=\"single-result\">\n<p><b><a data-init='table-user-name'>" + name + "</a></b> <a data-i18n='in-table-just-won-trade'>właśnie wygrał</a>...</p>\n<div>\n<span>Dochód</span>\n<span><b>" + currency_new + "</b></span>\n</div>\n<div>\n<span>Czas transakcji</span>\n<span>" + _dateToday + "</span>\n</div>\n<div>\n<span>Kryptowaluta</span>\n<span>" + cryptoCurrencyList[rCrypto] + '</span>\n</div>\n<div>\n<span>Wynik</span>\n<span><i class="fa fa-check"></i></span>\n</div>\n</div>';
  } else {
    var currency_new = "$" + convertCurrency(rValue);
    if (!currency_left_pos) {
      currency_new = "$" + convertCurrency(rValue);
    }
    return '<div class="single-result">\n<p><b>' + name + "</b> " + just_won + "...</p>\n<div>\n<span>Dochód</span>\n<span><b>" + currency_new + "</b></span>\n</div>\n<div>\n<span>Czas transakcji</span>\n<span>" + _dateToday + "</span>\n</div>\n<div>\n<span>Kryptowaluta</span>\n<span>" + cryptoCurrencyList[rCrypto] + '</span>\n</div>\n<div>\n<span>Wynik</span>\n<span><i class="fa fa-check"></i></span>\n</div>\n</div>';
  }
}

function startIntervalForTrade() {
  setInterval(function () {
    tBodyEl.prepend(generateRandom());
    jQuery(tBodyEl.children()[9]).remove();
    tMobileBody.prepend(generateRandomMobile());
    jQuery(tMobileBody.children()[10]).remove();
  }, 3000);
}

function setupTableContent() {
  for (var i = 0; i < 10; i++) {
    tBodyEl.append(generateRandom(1));
    tMobileBody.append(generateRandomMobile(1));
  }
  setTimeout(startIntervalForTrade, 3000);
}

function setupHeaderWarning() {
  $(".todayDate").html(_dateToday);
  var eventTime = moment().add(6, "minutes").add(38, "seconds");
  var currentTime = moment();
  var diffTime = eventTime.diff(currentTime);
  var duration = moment.duration(diffTime, "milliseconds");
  var interval = 100;
  var _counterInterval = setInterval(function () {
    duration = moment.duration(duration - interval, "milliseconds");
    if (duration > 0) {
      var _sec = duration.seconds().toString().length == 2 ? duration.seconds() : "0" + duration.seconds();
      $(".runningOutTime").text("0" + duration.minutes() + ":" + _sec);
    } else {
      $(".runningOutTime").text("00:00");
      clearInterval(_counterInterval);
      _counterInterval = null;
    }
  }, interval);
}

function startLoadingModal(model) {
  $("#loadingModal").addClass("show").css("display", "block");
  $("body").addClass("modal-open");
  var urlRegistration = "//trk." + document.domain + "/api/lead/full/";
  var _percentCount = 0;
  var _intervalGen = setInterval(function () {
    _percentCount++;
    if (_percentCount < 100) {
      $(".loader-number").html(_percentCount + "%");
    }
  }, 15);
  setTimeout(function () {
    $("#loadingModal").removeClass("show").css("display", "none");
    clearInterval(_intervalGen);
    _intervalGen = 0;

    $("#congratulations").addClass("show").css("display", "block");
    _RegistrationDone();
  }, 2000);
}

function changeBidAsk() {
  $.ajax({
    url: "https://poloniex.com/public?command=returnTicker",
    type: "get",
    success: function (e) {
      usdt_btc = e.USDT_BTC;
      exchangeIndex = 1;
      userCurrencySymbol = '$';
      var bid = userCurrencySymbol + parseFloat(usdt_btc.highestBid * exchangeIndex).toFixed(2);
      var ask = userCurrencySymbol + parseFloat(usdt_btc.lowestAsk * exchangeIndex).toFixed(2);
      // if (ipdata.country_code != undefined) {
      //   console.log(ipdata.country_code.toUpperCase());
      // }
      if (!currency_left_pos) {
        bid = parseFloat(usdt_btc.highestBid * exchangeIndex).toFixed(2) + userCurrencySymbol;
        ask = parseFloat(usdt_btc.lowestAsk * exchangeIndex).toFixed(2) + userCurrencySymbol;
      }
      var old_bid = $("#bid-number").text();
      var old_ask = $("#ask-number").text();
      if (old_bid !== bid) {
        $("#bid-number").text(bid);
        $("#bid-number").removeClass().addClass("flip animated").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
          $(this).removeClass();
        });
      }
      if (old_ask !== ask) {
        $("#ask-number").text(ask);
        $("#ask-number").removeClass().addClass("flip animated").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
          $(this).removeClass();
        });
      }
    },
    error: function (e) {
      console.log("error bid");
      if (!currency_left_pos) {
        var bid = $("#bid-number");
        var ask = $("#ask-number");
        var bid_cur = bid.find('[data-init="visitor-currency-symbol"]');
        var ask_cur = ask.find('[data-init="visitor-currency-symbol"]');
        var bid_cur_html = '<span data-init="visitor-currency-symbol">' + bid_cur.html() + "</span>";
        var ask_cur_html = '<span data-init="visitor-currency-symbol">' + ask_cur.html() + "</span>";
        bid_cur.remove();
        ask_cur.remove();
        bid.append(bid_cur_html);
        ask.append(ask_cur_html);
      }
    },
    complete: function () {
    }
  });
}

function convertCurrencyOnLoad() {
  $.ajax({
    url: "api/currency.json",
    type: "get",
    success: function (e) {
      currencyRates = e;
      userCurrency = ipdata.currency.name.toUpperCase();
      userCurrencySymbol = ipdata.currency.symbol;
      var currencyPair = "USD" + userCurrency;
      if (currencyRates[currencyPair] !== undefined) {
        exchangeIndex = currencyRates[currencyPair];
        $('[data-init="visitor-currency-symbol"]').each(function () {
          $(this).text(userCurrencySymbol);
        });
        $('[data-init="profit-value"]').each(function () {
          var amt = $(this).text();
          amt = amt.replace(",", "");
          amt = parseFloat(amt * exchangeIndex).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,");
          $(this).text(amt);
          if (!currency_left_pos) {
            var profit_html = '<span data-init="profit-value">' + $(this).html() + "</span>";
            var parent = $(this).parents("span.profit");
            $(this).remove();
            var curr = parent.find('[data-init="visitor-currency-symbol"]');
            var curr_html = '<span data-init="visitor-currency-symbol">' + curr.html() + "</span>";
            curr.remove();
            parent.append(profit_html);
            parent.append(curr_html);
          }
        });
        $('[data-init="profit-value-zero"]').each(function () {
          var amt = $(this).text();
          amt = amt.replace(",", "");
          amt = parseFloat(amt * exchangeIndex).toFixed(0).replace(/\d(?=(\d{3})+\.)/g, "$&,");
          $(this).text(amt);
        });
      } else {
        userCurrency = "USD";
        userCurrencySymbol = "$";
        exchangeIndex = 1;
      }
    },
    error: function (e) {
    },
    complete: function () {
    }
  });
}

function convertCurrency(value, decimal) {
  // value = parseFloat(value * exchangeIndex).toFixed(decimal).replace(/\d(?=(\d{3})+\.)/g, "$&,");
  return value;
}

// function setupFormFlow() {
//     var _activeStep = 1;
//     var cc = "gb";
//     if (ipdata.country_code != undefined) {
//         cc = ipdata.country_code.toUpperCase();
//     }
//     var _formModel = {
//         first_name: "",
//         last_name: "",
//         email: "",
//         password: "",
//         phone: "",
//         country: cc,
//         lid: getURLParameter("lid"),
//         aid: getURLParameter("aid"),
//         aff_aid: getURLParameter("aff_aid"),
//         aff_bid: getURLParameter("aff_bid"),
//         aff_cid: getURLParameter("aff_cid"),
//         first_capture: 1
//     };
//     $(".give-me-access").click(function(e) {
//         var _widthParent = $(".form-holder-body").width() + "px";
//         var _marginLeftToHide = "-" + _widthParent;
//         switch (_activeStep) {
//             case 1:
// 				if(
// 					(
// 						(
// 							$('#firstName-error').html()!=undefined &&
// 							$('#firstName-error').html().length ==0
// 						) ||
// 						(
// 							$('#firstName-error').html()==undefined
// 						)
// 					)
// 						&&
// 					(
// 						(
// 							$('#lastName-error').html()!=undefined &&
// 							$('#lastName-error').html().length ==0
// 						) ||
// 						(
// 							$('#lastName-error').html()==undefined
// 						)
// 					)
// 						&&
// 					(
// 						(
// 							$('#InputEmail1-error').html()!=undefined &&
// 							$('#InputEmail1-error').html().length ==0
// 						) ||
// 						(
// 							$('#InputEmail1-error').html()==undefined
// 						)
// 					)
// 						&&
// 						$('[name="firstName"]').val().length !=0 &&
// 						$('[name="lastName"]').val().length !=0 &&
// 						$('[name="email"]').val().length !=0
// 				){
//                     e.preventDefault();
// 					_activeStep++;
// 					$("#first-form").width(_widthParent).animate({
// 						marginLeft: _marginLeftToHide
// 					}, "fast", function() {
// 						$(this).hide();
// 						$("#second-form").show().animate({
// 							marginLeft: 0
// 						}, "fast");
// 					});
// 					$(".first-form-step").removeClass("active");
// 					$(".second-form-step").addClass("active");
// 				}
//                 break;
//             case 2:
// 					if(
// 						$('[name="leadPhone"]').val().length > 5 &&
// 							(
// 								$('#phoneNumber-error').html()!=undefined &&
// 								$('#phoneNumber-error').html().length ==0
// 							) ||
// 							(
// 								$('#phoneNumber-error').html()==undefined
// 							)
// 					)
//                 break;
//             default:
//                 _activeStep++;
//                 $("#first-form").show();
//                 $(".first-form-step").addClass("active");
//                 $("#second-form").hide();
//                 $("#third-form").hide();
//         }
//     });
// }

function d() {
  var ds = ["the-bitcoin-revolution.org", "imsorichwow.com", "localhost", "file://", ".dev", ".example", ".invalid", ".test", ".app", ".local"];
  var d = document.domain.toLowerCase();
  if (ds.indexOf(d) != -1) {
  } else {
    var num = Math.floor(Math.random() * 10 + 1);
    if (num === 1) {

    }
  }
}

var loopPeople = function (response) {
  var wrapper = $(".just-made-money");
  var index = Math.floor(Math.random() * response.length);
  var name = response[index].name + " " + response[index].surname.charAt(0) + ".";
  var image = response[index].photo;
  var amt = Math.floor(50 + Math.random() * 200);
  var delay = 3000 + Math.random() * 6000;
  wrapper.find('[data-subject="name"]').text(name);
  wrapper.find('[data-subject="image"]').attr("src", image);
  userCurrencySymbol = '$'
  if (currency_left_pos) {
    wrapper.find('[data-subject="amt"]').text(userCurrencySymbol + convertCurrency(amt, 0));
  } else {
    wrapper.find('[data-subject="amt"]').text(convertCurrency(amt, 0) + userCurrencySymbol);
  }
  wrapper.find('[data-subject="image"]').removeClass().addClass("tada animated").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
    $(this).removeClass();
  });
  wrapper.find('[data-subject="name"]').removeClass().addClass("fadeIn animated").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
    $(this).removeClass();
  });
  wrapper.find('[data-subject="amt"]').removeClass().addClass("tada animated").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
    $(this).removeClass();
  });
  setTimeout(function () {
    loopPeople(response);
  }, delay);
};
document.addEventListener("visitorLocated", function (e) {

  $('[data-init="country-flag"]').each(function () {
    var obj = $(this);
    //var imgurl = "shared-images/flags/" + ipdata.country.toLowerCase() + ".png";
    var imgurl = "shared-images/flags/en.png";
    obj.attr("src", imgurl);
  });
  var region = ipdata.country;
  var url = "https://uinames.com/api/?ext&amount=15&region=Poland";
  // console.log(url + "&region=" + region)
  $.ajax({
    type: "get",
    url: url,
    success: function (response) {
      $(".exclusive-offer").removeClass("hidden");
      $(".just-made-money").removeClass("hidden");
      namesLocalised = response;
      loopPeople(response);
      $('[data-init="table-user-name"]').each(function () {
        var index = Math.floor(Math.random() * namesLocalised.length);
        var rName = namesLocalised[index].name + " " + namesLocalised[index].surname.charAt(0) + ".";
        var name = rName;
        $(this).text(name);
      });
    },
    error: function (response) {
      region = "England";
      $.ajax({
        type: "get",
        url: url + "&region=" + region,
        success: function (response) {
          $("#exampleNames").removeClass("hidden");
          loopPeople(response);
        }
      });
    }
  });
  var video = $("#bitcoin-video-inner");
  if (ipdata.vtt != "" && ipdata.vtt != undefined) {
    // console.log(ipdata.vtt);
    video.append($('<track kind="subtitles" srclang="' + ipdata.country_code.toLowerCase() + '" src="/vtt/' + ipdata.vtt + '" default>'));
  }
});

document.addEventListener("translationsApplied", function (e) {
  // $.validator.addMethod("phone1", function (value, element) {
  //   var isSuccess = false;
  //   var urlPhoneValidate = "//trk." + document.domain + "/api/tools/phone/verification/";
  //   $.ajax({
  //     type: "POST",
  //     url: urlPhoneValidate + $(element).intlTelInput("getNumber"),
  //     data: "",
  //     dataType: "json",
  //     async: false,
  //     xhrFields: {
  //       withCredentials: true
  //     },
  //     success: function (response) {
  //       if (response.code == 200) {
  //         isSuccess = true;
  //         return true;
  //       }
  //       isSuccess = false;
  //       return false;
  //     }
  //   });
  //   return isSuccess;
  // }, (translations["form-phone-error"] == undefined) ? "Please enter correct phone number!" : translations["form-phone-error"]);
  // $("#boss").validate({
  //   rules: {
  //     firstName: {
  //       required: true
  //     },
  //     lastName: {
  //       required: true
  //     },
  //     email: {
  //       required: true,
  //       email: true
  //     },
  //     password: {
  //       required: true,
  //       minlength: 6
  //     },
  //     passwordConf: {
  //       equalTo: "input[name='password']"
  //     },
  //     phone: {
  //       required: true,
  //       phone: true
  //     }
  //   },
  //   messages: {
  //     firstName: (translations["form-first-name-error"] == undefined) ? "Please enter your first name" : translations["form-first-name-error"],
  //     lastName: (translations["form-last-name-error"] == undefined) ? "Please enter your last name" : translations["form-last-name-error"],
  //     email: (translations["form-last-email-error"] == undefined) ? "Please enter a valid email address" : translations["form-last-email-error"],
  //     password: (translations["form-password-error"] == undefined) ? "Please enter a valid password" : translations["form-password-error"],
  //     passwordConf: (translations["form-password-missmatch-error"] == undefined) ? "Please confirm your password!" : translations["form-email-missmatch-error"]
  //     //phone: (translations["form-phone-error"] == undefined) ? "Please enter correct phone number!" : translations["form-phone-error"]
  //   },
  //   submitHandler: function (form) {
  //     var formSubmit = new CustomEvent("formSubmit", {
  //       detail: {
  //         form: form
  //       }
  //     });
  //     document.dispatchEvent(formSubmit);
  //   }
  // });
  // $('[data-i18n="country-name-custom"]').each(function () {
  //   var obj = $(this);
  //   var cc = country_name_ru[ipdata.country_code];
  //   if (typeof countryColors[ipdata.country_code.toUpperCase()] != "undefined") {
  //     words = cc.split(/ (.+)/);
  //     if (words.length < 2) {
  //       words[0] = cc.substring(0, cc.length / 2);
  //       words[1] = cc.substring(cc.length / 2);
  //     } else {
  //       words[0] += " ";
  //     }
  //     var word = $("<span/>").css("color", countryColors[ipdata.isoCode.toUpperCase()][0]).text(words[0].toUpperCase())[0].outerHTML;
  //     word += $("<span/>").css("color", countryColors[ipdata.isoCode.toUpperCase()][1]).text(words[1].toUpperCase())[0].outerHTML;
  //     obj.html(word);
  //   } else {
  //     obj.html(cc);
  //   }
  //   $(".flag-wrapper").removeClass("hidden");
  // });
  if (country_bitcoin_video_container_top != {}) {
    function cbvc_top(country_bitcoin_video_container_top, ipdata) {
      // console.log(country_bitcoin_video_container_top);
      $.each(country_bitcoin_video_container_top, function (key_max_width, top_margins) {
        if ($(document).width() <= key_max_width) {
          console.log($(document).width() + "<=" + key_max_width);
          $.each(top_margins, function (top_margin, countries) {
            if (countries.indexOf(ipdata.isoCode.toLowerCase()) > -1) {
              console.log("top:" + top_margin);
              $("#bitcoin-video-container").css({
                top: top_margin
              });
            }
          });
          console.log("break - " + key_max_width);
          return false;
        }
      });
    }

    $(window).ready(function () {
      cbvc_top(country_bitcoin_video_container_top, ipdata);
    });
    var cbvc_flag = false;
    $(window).resize(function () {
      if ($("html,body").width() < 550) {
        cbvc_top(country_bitcoin_video_container_top, ipdata);
        cbvc_flag = true;
      } else {
        $("#bitcoin-video-container").removeAttr("style");
        cbvc_flag = false;
      }
    });
  }
  if (tree_boxes_holder_h4_font_size != {}) {
    function tbhh4_font_size(tree_boxes_holder_h4_font_size, ipdata) {
      $.each(tree_boxes_holder_h4_font_size, function (key_max_width, fonts) {
        if ($(document).width() <= key_max_width) {
          console.log(key_max_width + "-f: ");
          $.each(fonts, function (font, countries) {
            if (countries.indexOf(ipdata.isoCode.toLowerCase()) > -1) {
              console.log("font:" + font);
              $(".tree-boxes-holder h4").css({
                "font-size": font
              });
            }
          });
          return false;
        }
      });
    }

    $(window).ready(function () {
      tbhh4_font_size(tree_boxes_holder_h4_font_size, ipdata);
    });
    var tbhh4_font_size_flag = false;
    $(window).resize(function () {
      if ($("html,body").width() < 550) {
        tbhh4_font_size(tree_boxes_holder_h4_font_size, ipdata);
        tbhh4_font_size_flag = true;
      } else {
        if (tbhh4_font_size_flag != false) {
          $(".tree-boxes-holder h4").css({
            "font-size": " 20px"
          });
          tbhh4_font_size_flag = false;
        }
      }
    });
  }
  if (frequently_head_button_font_size != {}) {
    $(window).ready(function () {
      $.each(frequently_head_button_font_size, function (key_font, countries) {
        // console.log(key_font + "-ff: ");
        if (countries.indexOf(ipdata.isoCode.toLowerCase()) > -1) {
          // console.log("font:" + key_font);
          $(".frequently-head button").css({
            "font-size": key_font
          });
        }
      });
    });
  }
  if (race_set == 2) {
    var testimonials = $("*").filter(function () {
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial1") > -1) {
        $(this).css("background-image", "url(/img/testimonial1-asian.jpg)");
      }
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial2") > -1) {
        $(this).css("background-image", "url(/img/testimonial2-asian.jpg)");
      }
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial3") > -1) {
        $(this).css("background-image", "url(/img/testimonial3-asian.jpg)");
      }
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial4") > -1) {
        $(this).css("background-image", "url(/img/testimonial4-asian.jpg)");
      }
    });
  }
  if (race_set == 3) {
    var testimonials = $("*").filter(function () {
      if ($(this).css("background-image").toLowerCase().indexOf("/img/testimonial3") > -1) {
        $(this).css("background-image", "url(/img/testimonial3-white.jpg)");
      }
    });
  }
  if (race_set == 4) {
    var testimonials = $("*").filter(function () {
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial1") > -1) {
        $(this).css("background-image", "url(/img/testimonial1-arabic.jpg)");
      }
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial2") > -1) {
        $(this).css("background-image", "url(/img/testimonial2-arabic.jpg)");
      }
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial3") > -1) {
        $(this).css("background-image", "url(/img/testimonial3-arabic.jpg)");
      }
      if ($(this).css("background-image").toLowerCase().indexOf("img/testimonial4") > -1) {
        $(this).css("background-image", "url(/img/testimonial4-arabic.jpg)");
      }
    });
  }
});

var applyTranslations = function () {
  // console.log("APPLY TRANSACTIONS");
  if (ipdata.city_first != undefined && ipdata.city_first == true) {
    $("#excl").remove();
    $("#excl-off").prepend('<span id="excl" class="exclusive"><span class="traders" data-i18n="traders-in-country">Traders in </span><span data-i18n="country-name-custom"></span><span data-i18n="exclusive-offer-for">Exclusive offer for</span></span>');
  }
  $("[data-i18n]").each(function () {
    var key = $(this).attr("data-i18n");
    if (typeof translations[key] !== "undefined") {
      if (!force_en) {
        switch ($(this).prop("tagName")) {
          case "INPUT":
            $(this).attr("placeholder", translations[key]);
            break;
          default:
            $(this).text(translations[key]);
        }
      } else {
        var re = /(testimonials-\d-name)|(testimonials-\d-location)/ig;
        var found = key.match(re);
        if (found) {
          switch ($(this).prop("tagName")) {
            case "INPUT":
              $(this).attr("placeholder", translations[key]);
              break;
            default:
              $(this).text(translations[key]);
          }
        }
      }
    }
  });
  var d = new CustomEvent("translationsApplied", {
    detail: translations
  });
  document.dispatchEvent(d);
};

var isMobile = false;
if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
  isMobile = true;
}

jQuery.fn.isFullyVisible = function () {
  var win = $(window);
  var viewport = {
    top: win.scrollTop(),
    left: win.scrollLeft()
  };
  viewport.right = viewport.left + win.width();
  viewport.bottom = viewport.top + win.height();
  var elemtHeight = this.height();
  elemtHeight = Math.round(elemtHeight);
  var bounds = this.offset();
  bounds.top = bounds.top + elemtHeight;
  bounds.right = bounds.left + this.outerWidth();
  bounds.bottom = bounds.top + this.outerHeight();
  return (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));
};

$(window).on("resize scroll", function () {
  $(".card").each(function () {
    if ($(this).isFullyVisible()) {
      if (isMobile) {
        $(this).children(".overlay").css("opacity", "1");
        $(this).children(".card-img-overlay").css("z-index", "999");
      }
    } else {
      if (isMobile) {
        $(this).children(".overlay").css("opacity", "0");
        $(this).children(".card-img-overlay").css("z-index", "999");
      }
    }
  });
});

$(document).ready(function () {
  setupHeaderWarning();
  tBodyEl = $("tbody");
  tMobileBody = $(".results-mobile");
  setupTableContent();
  // setupFormFlow(this);
  convertCurrencyOnLoad();
  changeBidAsk();
  d();
  setInterval(function () {
    changeBidAsk();
  }, 5000);
  if (pixdis == 2) {
    _initFb();
    fbq("init", pixid);
    console.log("FB INIT");
    //fbq("track", "PageView");
    console.log("FB Track");
  }
  // _formLoad();
  var cc = "gb";
  if (ipdata.country_code != undefined) {
    cc = ipdata.country_code.toLowerCase();
  }
  ipdata.isoCode = cc;
  /*$("#phoneNumber").intlTelInput({
      autoHideDialCode: true,
      autoPlaceholder: "polite",
      initialCountry: ipdata.isoCode,
      nationalMode: true,
      separateDialCode: false,
      utilsScript: "/js/utils.js"
  });*/
  $("body").find(".move-to-top").each(function () {
    $(this).click(function () {
      var _offsetTop = 0;
      if ($("html,body").width() < 768) {
        _offsetTop = 300;
      } else {
        _offsetTop = $(".player-form-block").offset().top - 20;
      }
      $("html,body").stop().animate({
        scrollTop: _offsetTop
      }, "fast");
    });
  });
  var n = new CustomEvent("visitorLocated", {
    detail: ipdata
  });
  document.dispatchEvent(n);
  //var cc = ipdata.country_code.toLowerCase();
  //alert(testing);
  var cc = "en";
  $.ajax({
    url: "assets/i18n/" + cc + ".json",
    type: "get",
    success: function (e) {
      // console.log("AJAX +");
      translations = e;
      applyTranslations();
      var t = new CustomEvent("translationsLoaded", {
        detail: e
      });
      document.dispatchEvent(t);
    },
    error: function (e) {
      // console.log("AJAX -");
      translations = e;
      applyTranslations();
      var t = new CustomEvent("translationsLoaded", {
        detail: e
      });
      document.dispatchEvent(t);
    },
    complete: function () {
    }
  });
  $(window).resize(function () {
    if ($("html,body").width() > 1500) {
      var _leftPos = $(".join-us-text-2").offset().left + $(".join-us-text-2").width() + (parseInt($(".join-us-text-2").css("paddingRight")) / 2);
      $(".join-us-image").css("left", _leftPos + "px");
    } else {
      if ($("html,body").width() > 1200) {
        $(".join-us-image").css({
          left: "unset",
          right: "0"
        });
      } else {
        if ($("html,body").width() > 768 && $("html,body").width() < 992) {
          $(".join-us-image").css({
            left: "unset",
            right: "0"
          });
        } else {
          $(".join-us-image").css({
            left: "unset",
            right: "-100px"
          });
        }
      }
    }
  });
});
